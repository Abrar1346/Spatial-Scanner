import serial
import numpy as np
import open3d as o3d
import math

s = serial.Serial('COM7', 115200, timeout=40)
print("Opening: " + s.name)

# Reset the buffers of the UART port to delete the remaining data in the buffers
s.reset_output_buffer()
s.reset_input_buffer()

# Wait for the user's signal to start the program
input("Press Enter to start communication...")

# Send the character 's' to MCU via UART to signal MCU to start the transmission
s.write('s'.encode())
points = []
count = 0
theta = 0
x_increment = 0
while count < 96:
    line = s.readline().decode()
    try:
        r = float(line)
        # Convert polar coordinates to Cartesian coordinates
        y = r * math.sin(theta)
        z = r * math.cos(theta)
        points.append([x_increment, y, z])
        print("Received point:", x_increment, y, z)
        count += 1
        theta += math.pi / 16
        if count % 32 == 0:
            x_increment += 10  # Increase X-coordinate by 10 cm
            theta = 0  # Reset theta after every 32 points
    except ValueError:
        print("Invalid line received:", line)

# Close the serial port
print("Closing: " + s.name)
s.close()

# Convert the received points to a point cloud
point_cloud = o3d.geometry.PointCloud()
point_cloud.points = o3d.utility.Vector3dVector(points)

# Visualize the point cloud
o3d.visualization.draw_geometries([point_cloud])